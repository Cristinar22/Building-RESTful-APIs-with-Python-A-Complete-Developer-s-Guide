
import requests
from flask import Flask, jsonify
import logging

app = Flask(__name__)

@app.route('/fetch_data')
def fetch_data():
    try:
        response = requests.get("https://api.external-service.com/data", timeout=5)
        response.raise_for_status()  # Raise an exception for 4xx/5xx status codes
        return jsonify(response.json())
    except requests.exceptions.RequestException as e:
        app.logger.error(f"External API request failed: {e}")
        return jsonify({"error": "External API failure"}), 503

if __name__ == '__main__':
    app.run(debug=True)
    