
@app.route('/error')
def error_example():
    try:
        1 / 0  # This will raise a ZeroDivisionError
    except ZeroDivisionError as e:
        app.logger.error(f"Error: {e}")  # Log the error
        return "An error occurred", 500
    