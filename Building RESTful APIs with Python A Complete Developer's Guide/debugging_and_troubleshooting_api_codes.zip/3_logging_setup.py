
import logging
from flask import Flask

app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.DEBUG)  # Log all messages at DEBUG level or higher

@app.route('/')
def hello_world():
    app.logger.debug('Debugging message')
    app.logger.info('Informational message')
    app.logger.warning('Warning message')
    return "Hello, world!"

if __name__ == '__main__':
    app.run()
    