
from flask import Flask, jsonify
import psycopg2
import logging

app = Flask(__name__)

@app.route('/')
def get_tasks():
    try:
        conn = psycopg2.connect(dbname="todo_db", user="user", password="password", host="localhost")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM tasks")
        tasks = cursor.fetchall()
        return jsonify(tasks)
    except psycopg2.OperationalError as e:
        app.logger.error(f"Database connection error: {e}")
        return jsonify({"error": "Database connection failed"}), 500
    finally:
        if conn:
            conn.close()

if __name__ == '__main__':
    app.run(debug=True)
    