
@app.route('/')
def hello_world():
    # This will raise a ZeroDivisionError
    return 1 / 0
    