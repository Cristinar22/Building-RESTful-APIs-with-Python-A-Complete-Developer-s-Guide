
# Install Flask in the virtual environment
# With the virtual environment activated, run the following command:
# pip install flask

# Verify Flask installation
# pip show flask
