
# Create a Virtual Environment
# Open your terminal or command prompt and navigate to the project folder
# Run the following command:
# python -m venv myenv

# To activate on Windows:
# myenv\Scripts\activate

# To activate on Mac/Linux:
# source myenv/bin/activate
