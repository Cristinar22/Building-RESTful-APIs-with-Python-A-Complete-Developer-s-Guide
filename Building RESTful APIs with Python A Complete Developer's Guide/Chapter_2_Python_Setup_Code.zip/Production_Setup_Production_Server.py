
# Example command to use Gunicorn for production
# Install Gunicorn
# pip install gunicorn

# Run the Flask app with Gunicorn
# gunicorn app:app
