
# Instructions to check if pip is installed
# Open your terminal or command prompt and type:
# pip --version
# If pip is not installed, run:
# python -m ensurepip --upgrade
