
# Instructions for installing Python
# (This is just a placeholder comment as actual installation cannot be done via code)

# For Windows, download the installer from:
# https://www.python.org/downloads/
# On Mac, use Homebrew:
# brew install python
