
# Use python-dotenv to manage environment variables
# Install python-dotenv
# pip install python-dotenv

# Load environment variables in your code
from dotenv import load_dotenv
load_dotenv()
