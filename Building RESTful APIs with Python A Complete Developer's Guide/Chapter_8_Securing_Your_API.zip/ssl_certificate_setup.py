
from flask import Flask, request, jsonify
import ssl

app = Flask(__name__)

@app.route('/secure', methods=['GET'])
def secure_route():
    return jsonify({"message": "This is a secure endpoint!"}), 200

if __name__ == '__main__':
    # Serve the Flask app using SSL
    context = ('ssl/certificate.pem', 'ssl/private.key')  # Paths to the cert and key
    app.run(ssl_context=context)
