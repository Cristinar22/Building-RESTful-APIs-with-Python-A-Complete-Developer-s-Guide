
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

limiter = Limiter(get_remote_address)

@app.route('/tasks', methods=['GET'])
@limiter.limit("5 per minute")  # Limit to 5 requests per minute per IP
def get_tasks():
    return jsonify(tasks), 200
