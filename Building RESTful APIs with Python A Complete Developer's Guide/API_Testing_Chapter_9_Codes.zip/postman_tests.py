# Postman Test - GET Request
    pm.test("Status code is 200", function () {
      pm.response.to.have.status(200);
    });
    
    # Postman Test - POST Request
    pm.test("Task created successfully", function () {
      pm.response.to.have.status(201);
      pm.response.to.have.jsonBody('task');
    });
    
    # Postman Test - Error Handling
    pm.test("Status code is 400", function () {
      pm.response.to.have.status(400);
      pm.response.to.have.jsonBody('error');
    });
    