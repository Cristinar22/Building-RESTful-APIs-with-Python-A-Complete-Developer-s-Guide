heroku run python manage.py db upgrade
