
import os
import psycopg2

DATABASE_URL = os.environ.get('DATABASE_URL', 'postgres://localhost/to_do_db')
conn = psycopg2.connect(DATABASE_URL, sslmode='require')
