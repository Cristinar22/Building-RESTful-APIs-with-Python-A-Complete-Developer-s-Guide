heroku run python manage.py seed
