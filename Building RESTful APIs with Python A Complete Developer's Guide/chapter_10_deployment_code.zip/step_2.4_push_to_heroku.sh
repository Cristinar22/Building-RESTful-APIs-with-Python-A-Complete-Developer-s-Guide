
git add .
git commit -m "Prepare for Heroku deployment"
git push heroku master
