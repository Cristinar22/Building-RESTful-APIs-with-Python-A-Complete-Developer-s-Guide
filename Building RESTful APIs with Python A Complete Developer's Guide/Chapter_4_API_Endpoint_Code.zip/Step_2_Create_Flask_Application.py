
# Step 2: Create Your Flask Application
from flask import Flask, request, jsonify

app = Flask(__name__)

# Sample data to simulate a database
tasks = [
    {"id": 1, "task": "Learn Python"},
    {"id": 2, "task": "Build an API"},
]

# GET method to fetch all tasks
@app.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify(tasks), 200

# POST method to create a new task
@app.route('/tasks', methods=['POST'])
def create_task():
    new_task = request.get_json()  # Get the task data from the request
    new_id = len(tasks) + 1  # Create a new id
    new_task['id'] = new_id  # Assign the new id to the task
    tasks.append(new_task)  # Add the new task to the list
    return jsonify(new_task), 201  # Return the created task with a 201 status code

# PUT method to update an existing task
@app.route('/tasks/<int:id>', methods=['PUT'])
def update_task(id):
    task_to_update = next((task for task in tasks if task['id'] == id), None)
    if task_to_update is None:
        return jsonify({"message": "Task not found"}), 404
    data = request.get_json()
    task_to_update['task'] = data.get('task', task_to_update['task'])  # Update task description
    return jsonify(task_to_update), 200

# DELETE method to delete a task
@app.route('/tasks/<int:id>', methods=['DELETE'])
def delete_task(id):
    task_to_delete = next((task for task in tasks if task['id'] == id), None)
    if task_to_delete is None:
        return jsonify({"message": "Task not found"}), 404
    tasks.remove(task_to_delete)  # Remove task from the list
    return jsonify({"message": "Task deleted"}), 200

if __name__ == '__main__':
    app.run(debug=True)
