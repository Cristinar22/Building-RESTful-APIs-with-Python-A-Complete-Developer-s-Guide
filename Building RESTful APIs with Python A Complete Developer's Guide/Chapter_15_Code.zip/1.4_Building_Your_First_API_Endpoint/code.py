# First API Endpoint

from flask import Flask

app = Flask(__name__)

@app.route('/todo', methods=['GET'])
def get_todo():
    return {'task': 'Learn Flask'}

if __name__ == "__main__":
    app.run(debug=True)
