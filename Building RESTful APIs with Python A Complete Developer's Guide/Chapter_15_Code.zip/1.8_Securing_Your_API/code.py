# API Security with HTTPS

from flask import Flask, request
from OpenSSL import SSL

app = Flask(__name__)

context = ('cert.pem', 'key.pem')  # SSL certificates

@app.route('/secure', methods=['GET'])
def secure_route():
    return 'This is a secure API endpoint'

if __name__ == "__main__":
    app.run(debug=True, ssl_context=context)
