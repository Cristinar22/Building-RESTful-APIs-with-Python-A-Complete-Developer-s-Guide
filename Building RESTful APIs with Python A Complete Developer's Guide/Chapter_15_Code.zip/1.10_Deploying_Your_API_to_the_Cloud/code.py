# Deploying to Heroku (Example)

# Install Heroku CLI and push to Heroku using Git
# heroku create
# git push heroku master
