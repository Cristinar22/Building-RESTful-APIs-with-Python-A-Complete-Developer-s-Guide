# Debugging with Flask

import logging
from flask import Flask

app = Flask(__name__)

@app.route('/debug', methods=['GET'])
def debug_route():
    app.logger.debug('Debugging API call')
    return 'Check debug logs'

if __name__ == "__main__":
    app.run(debug=True)
