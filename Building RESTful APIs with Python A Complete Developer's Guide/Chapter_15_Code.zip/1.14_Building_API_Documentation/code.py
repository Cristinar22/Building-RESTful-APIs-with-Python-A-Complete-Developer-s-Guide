# Swagger Documentation

from flask import Flask
from flask_restplus import Api

app = Flask(__name__)
api = Api(app)

@api.route('/todos')
class TodoResource(Resource):
    def get(self):
        return {'todo': 'Learn Flask'}

if __name__ == "__main__":
    app.run(debug=True)
