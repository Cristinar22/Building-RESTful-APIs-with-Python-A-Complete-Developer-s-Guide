# Using HTTP Methods in Flask

from flask import Flask, request

app = Flask(__name__)

@app.route('/items', methods=['GET'])
def get_items():
    return {'items': ['item1', 'item2']}, 200

@app.route('/items', methods=['POST'])
def add_item():
    item = request.json.get('item')
    return {'message': f'Item {item} added'}, 201

if __name__ == "__main__":
    app.run(debug=True)
