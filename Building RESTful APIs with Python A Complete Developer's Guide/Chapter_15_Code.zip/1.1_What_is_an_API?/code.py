# API Concept
# An API is a way for different software applications to communicate with each other.
# Example code: A simple "Hello, World!" API

from flask import Flask

app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello, World!'

if __name__ == "__main__":
    app.run(debug=True)
