# Setting up Python environment

# Ensure Python 3.x is installed
# Install Flask using pip:
# pip install flask

from flask import Flask

app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Setup Successful'

if __name__ == "__main__":
    app.run(debug=True)
