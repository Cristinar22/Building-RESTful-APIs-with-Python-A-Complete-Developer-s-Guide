# Error Handling in Flask

from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/items/<item_id>', methods=['GET'])
def get_item(item_id):
    if not item_id.isdigit():
        return jsonify({"error": "Invalid item ID"}), 400
    return jsonify({"item": item_id})

if __name__ == "__main__":
    app.run(debug=True)
