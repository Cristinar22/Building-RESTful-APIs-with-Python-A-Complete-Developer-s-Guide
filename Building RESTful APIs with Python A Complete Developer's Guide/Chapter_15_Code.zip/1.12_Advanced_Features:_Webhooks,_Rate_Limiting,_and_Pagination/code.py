# Pagination

from flask import Flask, request

app = Flask(__name__)

@app.route('/items', methods=['GET'])
def get_items():
    page = request.args.get('page', 1, type=int)
    items = ['item1', 'item2', 'item3']
    return {'items': items[(page-1)*2:page*2]}, 200

if __name__ == "__main__":
    app.run(debug=True)
