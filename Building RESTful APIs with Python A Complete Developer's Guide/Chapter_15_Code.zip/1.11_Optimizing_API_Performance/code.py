# Using Compression for Faster Responses

from flask import Flask, jsonify
from flask_compress import Compress

app = Flask(__name__)
Compress(app)

@app.route('/data', methods=['GET'])
def get_data():
    return jsonify({"data": "Some optimized data"})

if __name__ == "__main__":
    app.run(debug=True)
