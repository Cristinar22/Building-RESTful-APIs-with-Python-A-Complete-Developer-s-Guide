# JWT Authentication

from flask import Flask, request, jsonify
import jwt

app = Flask(__name__)
SECRET_KEY = 'your_secret_key'

@app.route('/login', methods=['POST'])
def login():
    user = request.json.get('user')
    if user != 'admin':
        return jsonify({"error": "Unauthorized"}), 401
    token = jwt.encode({'user': user}, SECRET_KEY, algorithm='HS256')
    return jsonify({"token": token})

if __name__ == "__main__":
    app.run(debug=True)
