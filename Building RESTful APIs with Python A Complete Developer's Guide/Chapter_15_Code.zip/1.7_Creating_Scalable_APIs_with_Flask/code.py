# Scalable API with Caching

from flask import Flask
import redis

app = Flask(__name__)

cache = redis.Redis(host='localhost', port=6379, db=0)

@app.route('/data', methods=['GET'])
def get_data():
    data = cache.get('data')
    if not data:
        data = 'Some fetched data'
        cache.set('data', data)
    return {'data': data}

if __name__ == "__main__":
    app.run(debug=True)
