# Pytest Example

import pytest
from app import app

def test_api():
    client = app.test_client()
    response = client.get('/todo')
    assert response.status_code == 200
    assert response.json == {'task': 'Learn Flask'}
