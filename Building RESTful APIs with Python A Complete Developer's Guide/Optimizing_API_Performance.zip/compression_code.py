from flask import Flask, jsonify
from flask_compress import Compress

app = Flask(__name__)
Compress(app)  # Enable compression for the app

# Sample data for tasks
tasks = [
    {"id": 1, "task": "Learn Flask", "user_id": 1},
    {"id": 2, "task": "Build an API", "user_id": 1},
]

@app.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify(tasks), 200

if __name__ == '__main__':
    app.run(debug=True)
