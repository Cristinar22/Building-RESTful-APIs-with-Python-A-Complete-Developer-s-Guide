from flask import Flask, jsonify
from flask_caching import Cache
import redis

app = Flask(__name__)

# Setup Cache with Redis
app.config['CACHE_TYPE'] = 'redis'
app.config['CACHE_REDIS_URL'] = "redis://localhost:6379/0"
cache = Cache(app)

# Sample data for tasks
tasks = [
    {"id": 1, "task": "Learn Flask", "user_id": 1},
    {"id": 2, "task": "Build an API", "user_id": 1},
]

@app.route('/tasks', methods=['GET'])
@cache.cached(timeout=60)  # Cache the result for 60 seconds
def get_tasks():
    return jsonify(tasks), 200

if __name__ == '__main__':
    app.run(debug=True)
