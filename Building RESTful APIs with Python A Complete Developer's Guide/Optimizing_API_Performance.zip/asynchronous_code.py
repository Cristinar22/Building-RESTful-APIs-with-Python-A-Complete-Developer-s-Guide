from flask import Flask, jsonify
from celery import Celery
import time

app = Flask(__name__)

# Set up Celery
def make_celery(app):
    celery = Celery(
        app.import_name,
        backend=app.config['CELERY_RESULT_BACKEND'],
        broker=app.config['CELERY_BROKER_URL']
    )
    celery.conf.update(app.config)
    return celery

app.config['CELERY_BROKER_URL'] = 'redis://localhost:6379/0'
app.config['CELERY_RESULT_BACKEND'] = 'redis://localhost:6379/0'
celery = make_celery(app)

# Sample data for tasks
tasks = [
    {"id": 1, "task": "Learn Flask", "user_id": 1},
    {"id": 2, "task": "Build an API", "user_id": 1},
]

@app.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify(tasks), 200

@app.route('/long_task', methods=['GET'])
def long_task():
    task = background_task.apply_async()
    return jsonify({"task_id": task.id}), 202

@celery.task
def background_task():
    time.sleep(10)  # Simulate a long-running task
    return 'Task Complete!'

if __name__ == '__main__':
    app.run(debug=True)
