# Integrating Swagger UI with Flask

# Step 1: Installing Flask-RESTPlus
pip install flask-restplus

# Step 2: Setting Up Swagger UI in Flask
from flask import Flask
from flask_restplus import Api, Resource

app = Flask(__name__)

# Set up Flask-RESTPlus API
api = Api(app, version='1.0', title='To-Do List API',
          description='A simple API to manage tasks',
          doc='/swagger')

# Define a simple resource
@api.route('/tasks')
class TaskList(Resource):
    def get(self):
        return {"tasks": ["Task 1", "Task 2", "Task 3"]}

if __name__ == '__main__':
    app.run(debug=True)

# Step 3: Start the Flask App
# python app.py

# Step 4: Access Swagger UI
# Visit: http://localhost:5000/swagger
