# Documenting API Endpoints with Swagger UI

@api.route('/tasks')
class TaskList(Resource):
    def get(self):
        """
        Retrieve the list of tasks
        ---
        responses:
          200:
            description: A list of tasks
            examples:
              application/json: {"tasks": ["Task 1", "Task 2", "Task 3"]}
        """
        return {"tasks": ["Task 1", "Task 2", "Task 3"]}

    def post(self):
        """
        Create a new task
        ---
        parameters:
          - name: task
            in: body
            required: true
            type: string
            description: The task to add to the list
        responses:
          201:
            description: Task successfully created
          400:
            description: Bad request if the task is missing
        """
        # In a real API, you would add the task to a database
        return {"message": "Task created"}, 201
