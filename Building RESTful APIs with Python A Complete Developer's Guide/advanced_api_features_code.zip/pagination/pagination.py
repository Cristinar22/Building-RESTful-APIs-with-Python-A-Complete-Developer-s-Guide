@app.route('/tasks', methods=['GET'])
def get_tasks():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)
    tasks_page = tasks[(page-1)*per_page:page*per_page]  # Simulate pagination
    
    return jsonify({"tasks": tasks_page, "page": page, "per_page": per_page}), 200
