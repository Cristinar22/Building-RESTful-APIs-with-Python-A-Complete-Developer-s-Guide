@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.get_json()  # Parse the incoming JSON data
    # Log the data or handle it as needed
    print(f"Webhook received: {data}")
    return jsonify({"message": "Webhook received"}), 200

import requests

@app.route('/tasks/<task_id>', methods=['PUT'])
def update_task(task_id):
    task_data = request.get_json()
    task = find_task_by_id(task_id)  # This function finds the task from the database
    task.update(task_data)
    
    # Send a webhook notification
    webhook_url = "https://example.com/webhook"  # Replace with the actual webhook URL
    webhook_data = {"task_id": task_id, "task": task}
    requests.post(webhook_url, json=webhook_data)

    return jsonify({"message": "Task updated and webhook sent"}), 200
