
import datetime
import jwt
from flask import Flask, request, jsonify

app = Flask(__name__)

SECRET_KEY = 'your_secret_key'

users = [{"id": 1, "username": "testuser", "password": "password123"}]

@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    if not username or not password:
        return jsonify({"message": "Username and password are required"}), 400
    for user in users:
        if user['username'] == username:
            return jsonify({"message": "User already exists"}), 400
    new_user = {"id": len(users) + 1, "username": username, "password": password}
    users.append(new_user)
    token = generate_token(new_user['id'])
    return jsonify({"message": "User created successfully", "token": token}), 201

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    if not username or not password:
        return jsonify({"message": "Username and password are required"}), 400
    user = next((user for user in users if user['username'] == username), None)
    if user is None or user['password'] != password:
        return jsonify({"message": "Invalid username or password"}), 401
    token = generate_token(user['id'])
    return jsonify({"message": "Login successful", "token": token}), 200

def generate_token(user_id):
    expiration_time = datetime.datetime.utcnow() + datetime.timedelta(hours=1)
    payload = {"user_id": user_id, "exp": expiration_time}
    token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")
    return token
