
# Sample Postman testing script (description for the user)

# 1. Register a new user
POST /register
Body (JSON):
{
  "username": "john_doe",
  "password": "securepassword"
}

# 2. Login with the user
POST /login
Body (JSON):
{
  "username": "john_doe",
  "password": "securepassword"
}

# 3. Access the tasks endpoint with token
GET /tasks
Headers:
  Authorization: Bearer <token>

# 4. Create a new task
POST /tasks
Body (JSON):
{
  "task": "Finish Flask tutorial"
}
