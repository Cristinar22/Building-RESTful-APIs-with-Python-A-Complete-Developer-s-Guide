
from flask import Flask, request, jsonify
from functools import wraps
import jwt

app = Flask(__name__)

tasks = [{"id": 1, "task": "Learn Flask", "user_id": 1}]

@app.route('/tasks', methods=['GET'])
@token_required
def get_tasks(current_user):
    user_tasks = [task for task in tasks if task['user_id'] == current_user['id']]
    return jsonify(user_tasks), 200

@app.route('/tasks', methods=['POST'])
@token_required
def create_task(current_user):
    data = request.get_json()
    task_name = data.get('task')
    if not task_name:
        return jsonify({"message": "Task name is required"}), 400
    new_task = {"id": len(tasks) + 1, "task": task_name, "user_id": current_user['id']}
    tasks.append(new_task)
    return jsonify(new_task), 201
