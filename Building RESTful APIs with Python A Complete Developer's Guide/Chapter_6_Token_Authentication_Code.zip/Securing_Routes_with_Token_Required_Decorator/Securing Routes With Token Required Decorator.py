
from functools import wraps
from flask import request, jsonify
import jwt

SECRET_KEY = 'your_secret_key'

def token_required(f):
    @wraps(f)
    def decorator(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            token = request.headers['Authorization'].split(" ")[1]
        if not token:
            return jsonify({"message": "Token is missing"}), 403
        try:
            decoded = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
            current_user = next((user for user in users if user['id'] == decoded['user_id']), None)
            if current_user is None:
                raise Exception("User not found")
        except Exception as e:
            return jsonify({"message": f"Token is invalid: {str(e)}"}), 403
        return f(current_user, *args, **kwargs)
    return decorator
