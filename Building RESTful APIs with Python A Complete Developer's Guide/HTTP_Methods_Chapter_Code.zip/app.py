
from flask import Flask, request, jsonify

app = Flask(__name__)

# Sample data to mimic a simple database
tasks = [
    {"id": 1, "task": "Learn Flask"},
    {"id": 2, "task": "Build an API"},
]

# GET method to retrieve all tasks
@app.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify(tasks), 200

# POST method to create a new task
@app.route('/tasks', methods=['POST'])
def add_task():
    new_task = request.get_json()
    new_id = len(tasks) + 1
    new_task["id"] = new_id
    tasks.append(new_task)
    return jsonify(new_task), 201

if __name__ == '__main__':
    app.run(debug=True)
